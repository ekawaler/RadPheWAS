metabias <- function (x, ...) 
  UseMethod("metabias")

bubble <- function (x, ...) 
  UseMethod("bubble")
